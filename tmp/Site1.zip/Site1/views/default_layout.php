<div class="u-page-root"><section class="u-align-center u-clearfix u-section-1" id="sec-3c97">
  <div class="u-clearfix u-sheet u-valign-middle-md u-valign-middle-sm u-valign-middle-xs u-sheet-1"><!--post_details--><!--post_details_options_json--><!--{"source":""}--><!--/post_details_options_json--><!--blog_post-->
    <div class="u-container-style u-expanded-width u-post-details u-post-details-1">
      <div class="u-container-layout u-valign-middle u-container-layout-1"><!--blog_post_image-->
        <!--/blog_post_image--><!--blog_post_header-->
        <!--/blog_post_header--><!--blog_post_metadata-->
        <!--/blog_post_metadata--><!--blog_post_content-->
        <div class="u-align-justify u-blog-control u-post-content u-text u-text-2"><?php $this->renderComponent(); ?></div><!--/blog_post_content-->
      </div>
    </div><!--/blog_post--><!--/post_details-->
  </div>
</section></div>