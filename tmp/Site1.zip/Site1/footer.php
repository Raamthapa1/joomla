<?php
    $document = JFactory::getDocument();
?>
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-75f1">
  <div class="u-clearfix u-sheet u-sheet-1">
    <p class="u-small-text u-text u-text-variant u-text-1">Sample text. Click to select the Text Element.</p>
  </div>
</footer>
    